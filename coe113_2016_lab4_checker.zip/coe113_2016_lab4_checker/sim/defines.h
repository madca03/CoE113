`define CLK_PERIOD 20
`define INPUT_DELAY 4

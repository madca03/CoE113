#!/bin/bash

cd /nfs/home/snap/Work/coe113_2016_lab4_checker/check
rm -rf *
mkdir mapped

cd /nfs/home/snap/Work/coe113_2016_lab4_checker/sim
rm -rf csrc
rm -rf DVEfiles
rm -rf simv*
rm -rf *.vpd
rm -rf ucli.key
rm -rf vcs.log

